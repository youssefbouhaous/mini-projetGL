<?php
class DAO {
  private $dbh;

  public function __construct() {
    $this->dbh = new PDO('mysql:host=localhost;dbname=projet', "root", "");
  }

  public function getAllDishes() {
    $stm = $this->dbh->prepare("SELECT DISTINCT nom FROM plat");
    $stm->execute();
    return $stm->fetchAll(PDO::FETCH_ASSOC);
  }

  public function getIngredientsByDish($dishName) {
    $stm = $this->dbh->prepare("SELECT * FROM plat JOIN ingrediants ON plat.ingrediant = ingrediants.nom WHERE plat.nom = ?");
    $stm->bindParam(1, $dishName);
    $stm->execute();
    return $stm->fetchAll(PDO::FETCH_ASSOC);
  }

  public function getImageSrcByDish($dishName) {
    $stm = $this->dbh->prepare("SELECT srcimg FROM imgplat WHERE nom = ?");
    $stm->bindParam(1, $dishName);
    $stm->execute();
    $imageRow = $stm->fetch(PDO::FETCH_ASSOC);
    return ($imageRow && isset($imageRow['srcimg'])) ? $imageRow['srcimg'] : null;
  }
}
