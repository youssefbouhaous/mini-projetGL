<?php
function renderView($closestDish, $imageSrc, $closestDistance, $ingredients) {
  echo '<h2>Closest Dish: ' . $closestDish . '</h2>';
  
  if ($imageSrc) {
    echo '<img src="' . $imageSrc . '" alt="' . $closestDish . '" width="200">';
  } else {
    echo '<p>No image found for the closest dish.</p>';
  }
  
  echo '<table class="table table-bordered mt-4">';
  echo '<thead class="thead-dark">';
  echo '<tr><th>Ingredient</th><th>Quantity</th></tr>';

  foreach ($ingredients as $ingredient) {
    echo '<tr>';
    echo '<td>' . $ingredient['ingrediant'] . '</td>';
    echo '<td>' . $ingredient['quantite'] . '</td>';
    echo '</tr>';
  }

  echo '</table>';
}
