<?php
include "../model/utilisateur.php";
session_start();
if(isset($_SESSION['utilisateur'])){
    $utilisateur = $_SESSION['utilisateur'];
    echo "Bienvenue ".$utilisateur->getNom();
} else {
    header('location:log.html');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenue</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #C4E7B1;
      background-size: cover;
    }
    .container {
      padding-top: 150px;
      text-align: center;
    }
    h1 {
      color: #fff;
      font-size: 36px;
      margin-bottom: 30px;
    }
    .btn-container {
      margin-bottom: 20px;
    }
    .btn-container .btn {
      width: 200px;
      height: 200px;
      margin-right: 20px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to the Bienvenue Page</h1>
    <h2>Hello, <?php echo $username. " " . $firstname ?>!</h2>
    

    <div class="btn-container">
      <a href="fct1.php" class="btn btn-outline-success">fct1</a>
      <a href="fct2.php" class="btn btn-outline-success">fct2</a>
    </div>

    <div class="btn-container">
      
      <a href="fct3.php" class="btn btn-outline-success">fct3</a>
      <a href="fct4.php" class="btn btn-outline-success">fct4</a>
    </div>
    <a href="logout.php" class="btn btn-danger">Logout</a>
  </div>
</body>
</html>
