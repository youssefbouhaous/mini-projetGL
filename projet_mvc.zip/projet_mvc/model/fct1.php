<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fct1 Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #C4E7B1;
      background-size: cover;
    }

    .container {
      padding-top: 150px;
    }

    .footer {
      background-color: #f8f9fa;
      padding: 5px;
      text-align: center;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Fct1 Page</h1>
    <form action="" method="post">
      <label for="proteins">Proteins:</label>
      <input type="text" name="proteins" id="proteins" class="form-control">
      <label for="glucids">Glucids:</label>
      <input type="text" name="glucids" id="glucids" class="form-control">
      <label for="sugar">Sugar:</label>
      <input type="text" name="sugar" id="sugar" class="form-control">
      <button type="submit" class="btn btn-primary mt-3">Find Closest Dish</button>
    </form>
    <div class="container d-flex justify-content-end fixed-bottom mb-3 mr-3">
      <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
    <?php
    if (isset($_POST['proteins']) && isset($_POST['glucids']) && isset($_POST['sugar'])) {
      require_once 'controller-fct2.php';

      $targetProteins = (float)$_POST['proteins'];
      $targetGlucids = (float)$_POST['glucids'];
      $targetSugar = (float)$_POST['sugar'];

      processFormSubmission($targetProteins, $targetGlucids, $targetSugar);
    }
    ?>
  </div>
</body>

</html>
