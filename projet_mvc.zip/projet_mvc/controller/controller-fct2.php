<?php
require_once 'dao-fct2.php';
require_once 'view-fct2.php';

// Fonction pour traiter les données soumises par le formulaire
function processFormSubmission($targetProteins, $targetGlucids, $targetSugar) {
  $dao = new DAO();
  $dishes = $dao->getAllDishes();

  $closestDish = null;
  $closestDistance = PHP_FLOAT_MAX;

  foreach ($dishes as $dish) {
    $ingredients = $dao->getIngredientsByDish($dish['nom']);

    if (!empty($ingredients)) {
      $sumProteins = 0;
      $sumGlucids = 0;
      $sumSugar = 0;

      foreach ($ingredients as $ingredient) {
        $quantity = (float)$ingredient['quantite'];
        $sumProteins += ($ingredient['Proteines'] * $quantity / 100);
        $sumGlucids += ($ingredient['Glucides'] * $quantity / 100);
        $sumSugar += ($ingredient['Sucres'] * $quantity / 100);
      }

      $distance = sqrt(pow($sumProteins - $targetProteins, 2) + pow($sumGlucids - $targetGlucids, 2) + pow($sumSugar - $targetSugar, 2));

      if ($distance < $closestDistance) {
        $closestDish = $dish['nom'];
        $closestDistance = $distance;
      }
    }
  }

  $imageSrc = $dao->getImageSrcByDish($closestDish);

  renderView($closestDish, $imageSrc, $closestDistance, $dao->getIngredientsByDish($closestDish));
}
?>